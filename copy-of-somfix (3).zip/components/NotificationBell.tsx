
import React, { useState, useRef, useEffect } from 'react';
import { NotificationMessage } from '../types';
import { BellIcon } from './icons/BellIcon';
import { TrashCanIcon } from './icons/TrashCanIcon';

interface NotificationBellProps {
  notifications: NotificationMessage[];
  onClearNotifications: (recipientId: string) => void;
  recipientId: string;
}

export const NotificationBell: React.FC<NotificationBellProps> = ({ notifications, onClearNotifications, recipientId }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const unreadCount = notifications.filter(n => !n.read).length;

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const sortedNotifications = [...notifications].sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

  return (
    <div className="relative">
      <button 
        onClick={() => setIsOpen(!isOpen)} 
        className="relative p-2 rounded-full hover:bg-sky-600 focus:outline-none focus:ring-2 focus:ring-sky-400 focus:ring-opacity-75"
      >
        <BellIcon className="w-7 h-7 text-sky-100" />
        {unreadCount > 0 && (
          <span className="absolute top-0 right-0 block h-5 w-5 transform -translate-y-1 translate-x-1">
             <span className="absolute inline-flex h-full w-full rounded-full bg-red-500 opacity-75 animate-ping"></span>
            <span className="relative inline-flex rounded-full h-5 w-5 bg-red-600 text-white text-xs font-semibold items-center justify-center">
              {unreadCount}
            </span>
          </span>
        )}
      </button>
      {isOpen && (
        <div 
          ref={dropdownRef} 
          className="absolute right-0 mt-2 w-80 md:w-96 bg-white rounded-lg shadow-xl overflow-hidden z-50 border border-slate-200"
        >
          <div className="p-3 flex justify-between items-center bg-slate-50 border-b border-slate-200">
            <h3 className="font-semibold text-slate-700">Notifications</h3>
            {notifications.length > 0 && (
                 <button
                    onClick={() => {
                        onClearNotifications(recipientId);
                        setIsOpen(false);
                    }}
                    className="text-xs text-sky-600 hover:text-sky-800 hover:underline flex items-center"
                    title="Clear all notifications"
                >
                    <TrashCanIcon className="w-4 h-4 mr-1" /> Clear All
                </button>
            )}
          </div>
          <div className="max-h-96 overflow-y-auto">
            {sortedNotifications.length === 0 ? (
              <p className="text-slate-500 p-4 text-center">No new notifications.</p>
            ) : (
              <ul>
                {sortedNotifications.map((notification) => (
                  <li 
                    key={notification.id} 
                    className={`p-3 border-b border-slate-100 hover:bg-slate-50 ${notification.read ? 'opacity-70' : 'font-medium'}`}
                  >
                    <p className="text-sm text-slate-800">{notification.message}</p>
                    <p className="text-xs text-slate-500 mt-1">
                      {new Date(notification.timestamp).toLocaleString()}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
    