
import React, { useState, useMemo, useEffect } from 'react';
// Fix: Removed 'User' as it's not exported from types.ts and currentUser uses an inline type.
import { ServiceRecord, UserRole } from '../types'; 
import { ArchiveBoxIcon, UserCircleIcon, PhoneIcon, CogIcon, WrenchScrewdriverIcon, CheckBadgeIcon, MagnifyingGlassIcon } from '../constants';

interface CustomerHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  history: ServiceRecord[];
  currentUser: { role: UserRole; id: string; name: string }; // Pass current user for context if needed
}

export const CustomerHistoryModal: React.FC<CustomerHistoryModalProps> = ({ isOpen, onClose, history, currentUser }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [customerDetailView, setCustomerDetailView] = useState<{
    name: string;
    phone: string;
    count: number;
    records: ServiceRecord[];
  } | null>(null);

  const baseSortedHistory = useMemo(() => {
    // Sorts the history prop. Newest completed tasks first.
    return [...history].sort((a, b) => (b.completedAt?.getTime() || 0) - (a.completedAt?.getTime() || 0));
  }, [history]);

  useEffect(() => {
    if (!searchTerm.trim()) {
      setCustomerDetailView(null);
    } else {
      const lowerSearchTerm = searchTerm.toLowerCase().replace(/\D/g, ''); // Keep only digits for phone search
      const matchedRecord = baseSortedHistory.find(record =>
        record.customerPhoneNumber.toLowerCase().replace(/\D/g, '').includes(lowerSearchTerm)
      );

      if (matchedRecord) {
        const targetPhoneNumber = matchedRecord.customerPhoneNumber;
        const customerRecords = baseSortedHistory.filter(
          record => record.customerPhoneNumber === targetPhoneNumber
        ).sort((a,b) => (b.completedAt?.getTime() || 0) - (a.completedAt?.getTime() || 0)); 

        setCustomerDetailView({
          name: customerRecords[0].customerName,
          phone: targetPhoneNumber,
          count: customerRecords.length,
          records: customerRecords,
        });
      } else {
        setCustomerDetailView(null);
      }
    }
  }, [searchTerm, baseSortedHistory]);

  if (!isOpen) return null;

  const renderRecordItem = (record: ServiceRecord) => (
    <div key={record.id} className="bg-white p-4 rounded-lg shadow-md border border-slate-200 hover:shadow-lg transition-shadow">
      <div className="flex justify-between items-start mb-2">
        <h3 className="text-md font-semibold text-sky-700">{record.description}</h3>
        <span className="text-xs font-medium text-blue-600 bg-blue-100 px-2 py-0.5 rounded-full">{record.status}</span>
      </div>
      <p className="text-xs text-slate-500 mb-3">
        Task ID: {record.id} | Completed: {record.completedAt ? new Date(record.completedAt).toLocaleString() : 'N/A'}
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2 text-sm text-slate-700">
        {!customerDetailView && ( 
            <>
            <div className="flex items-center">
                <UserCircleIcon className="w-4 h-4 mr-2 text-slate-500 flex-shrink-0" />
                <strong>Customer:</strong>&nbsp;{record.customerName}
            </div>
            <div className="flex items-center">
                <PhoneIcon className="w-4 h-4 mr-2 text-slate-500 flex-shrink-0" />
                <strong>Phone:</strong>&nbsp;{record.customerPhoneNumber}
            </div>
            </>
        )}
        <div className="flex items-center">
          <CogIcon className="w-4 h-4 mr-2 text-slate-500 flex-shrink-0" />
          <strong>Appliance:</strong>&nbsp;{record.applianceType}
        </div>
        <div className="flex items-center">
          <WrenchScrewdriverIcon className="w-4 h-4 mr-2 text-slate-500 flex-shrink-0" />
          <strong>Technician:</strong>&nbsp;{record.assignedTechnicianName || 'N/A'}
        </div>
      </div>
      <p className="mt-2 text-sm text-slate-600">
        <strong>Issue:</strong>&nbsp;{record.failureDetails}
      </p>
      <p className="mt-2 text-sm font-semibold text-slate-800 text-right">
        Total Amount: ${record.totalAmountUSD.toFixed(2)}
      </p>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-gradient-to-br from-slate-50 to-gray-100 p-6 sm:p-8 rounded-xl shadow-2xl w-full max-w-4xl transform transition-all duration-300 ease-in-out scale-100 my-8 max-h-[90vh] flex flex-col">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-4 pb-4 border-b border-slate-300 gap-4">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-800 flex items-center">
            <ArchiveBoxIcon className="w-7 h-7 sm:w-8 sm:h-8 mr-3 text-sky-600" />
            Service History
          </h2>
          <div className="relative w-full sm:w-auto sm:max-w-xs">
            <input
              type="text"
              placeholder="Search by customer phone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full p-2.5 pl-10 border border-slate-300 rounded-lg shadow-sm focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition duration-150"
            />
            <MagnifyingGlassIcon className="w-5 h-5 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
          </div>
          <button
            onClick={onClose}
            className="text-slate-500 hover:text-slate-700 text-3xl font-light sm:ml-4"
            aria-label="Close modal"
          >
            &times;
          </button>
        </div>

        <div className="overflow-y-auto space-y-4 pr-2 -mr-2 flex-grow">
          {customerDetailView ? (
            <div>
              <div className="mb-6 p-4 bg-sky-100 border border-sky-300 rounded-lg">
                <h3 className="text-xl font-semibold text-sky-800 mb-2">Customer: {customerDetailView.name}</h3>
                <p className="text-sm text-slate-700"><PhoneIcon className="w-4 h-4 inline mr-1" /> {customerDetailView.phone}</p>
                <p className="text-sm text-slate-700 mt-1">
                  <CheckBadgeIcon className="w-4 h-4 inline mr-1 text-green-600" /> 
                  Served <strong className="text-sky-700">{customerDetailView.count}</strong> time(s).
                </p>
              </div>
              <h4 className="text-lg font-semibold text-slate-700 mb-3">Service Details:</h4>
              {customerDetailView.records.length > 0 ? (
                customerDetailView.records.map(record => renderRecordItem(record))
              ) : (
                 <p className="text-slate-500 text-center py-5">No records found for this customer view.</p> 
              )}
            </div>
          ) : baseSortedHistory.length === 0 ? (
            <div className="text-center py-10 px-6 text-slate-600 flex-grow flex flex-col justify-center items-center">
              <ArchiveBoxIcon className="w-16 h-16 text-slate-400 mb-4" />
              <p className="text-xl">No completed services yet.</p>
              <p className="text-sm text-slate-500">Completed tasks will appear here.</p>
            </div>
          ) : (
             baseSortedHistory.map(record => renderRecordItem(record))
          )}
          {/* Fallback for no search results when search term is active but no customerDetailView */}
          {searchTerm && !customerDetailView && baseSortedHistory.length > 0 && (
             <div className="text-center py-10 px-6 text-slate-600">
                <MagnifyingGlassIcon className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                <p className="text-lg">No customer found matching "{searchTerm}".</p>
             </div>
          )}
        </div>

        <div className="mt-6 pt-4 border-t border-slate-300 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-lg text-slate-700 bg-slate-200 hover:bg-slate-300 transition duration-150 font-medium"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
