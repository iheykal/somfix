
import React from 'react';
import { BriefcaseIcon as HeroBriefcaseIcon } from '../../constants';

export const BriefcaseIcon: React.FC<{ className?: string }> = ({ className }) => (
  <HeroBriefcaseIcon className={className} />
);
    