
import React from 'react';
import { WrenchScrewdriverIcon } from '../../constants';

export const WrenchIcon: React.FC<{ className?: string }> = ({ className }) => (
  <WrenchScrewdriverIcon className={className} />
);
    