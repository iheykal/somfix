
import React from 'react';
// Fix: Import TaskStatus
import { Task, UserRole, TaskStatus } from '../types';
import { TaskItem } from './TaskItem';

interface TaskListProps {
  tasks: Task[];
  currentUserRole: UserRole;
  currentUserId: string;
  onAcceptTask?: (taskId: string) => void;
  onRejectTask?: (taskId: string) => void;
  onCompleteTask?: (taskId: string) => void; // New prop
  listTitle: string;
  emptyStateMessage: string;
}

export const TaskList: React.FC<TaskListProps> = ({ 
    tasks, 
    currentUserRole, 
    currentUserId, 
    onAcceptTask, 
    onRejectTask, 
    onCompleteTask, // Added prop
    listTitle, 
    emptyStateMessage 
}) => {
  const sortedTasks = [...tasks].sort((a, b) => {
    // Sort by status first (PENDING, ACCEPTED, COMPLETED, REJECTED), then by creation date
    const statusOrder = [TaskStatus.PENDING, TaskStatus.ACCEPTED, TaskStatus.COMPLETED, TaskStatus.REJECTED];
    const statusA = statusOrder.indexOf(a.status);
    const statusB = statusOrder.indexOf(b.status);
    if (statusA !== statusB) {
      return statusA - statusB;
    }
    return b.createdAt.getTime() - a.createdAt.getTime();
  });
  
  return (
    <div className="mt-6">
      <h2 className="text-2xl font-semibold text-slate-700 mb-5">{listTitle}</h2>
      {sortedTasks.length === 0 ? (
        <div className="text-center py-10 px-6 bg-slate-50 rounded-lg shadow">
          <svg className="mx-auto h-12 w-12 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
            <path vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m-9 1V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
          </svg>
          <h3 className="mt-2 text-lg font-medium text-slate-900">{emptyStateMessage}</h3>
          <p className="mt-1 text-sm text-slate-500">
            {currentUserRole === UserRole.MANAGER ? "Click 'Add New Task' to get started." : "New tasks assigned to you will appear here."}
          </p>
        </div>
      ) : (
        <ul className="space-y-5">
          {sortedTasks.map(task => (
            <TaskItem
              key={task.id}
              task={task}
              currentUserRole={currentUserRole}
              currentUserId={currentUserId}
              onAcceptTask={onAcceptTask}
              onRejectTask={onRejectTask}
              onCompleteTask={onCompleteTask} // Pass down
            />
          ))}
        </ul>
      )}
    </div>
  );
};