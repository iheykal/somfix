
import React from 'react';
import { APP_TITLE, BriefcaseIcon as ManagerIcon, ArchiveBoxIcon } from '../constants';
import { NotificationBell } from './NotificationBell';
import { NotificationMessage, UserRole } from '../types';

interface HeaderProps {
  currentUserRole: UserRole;
  currentUserName: string;
  notifications: NotificationMessage[];
  onClearNotifications: (recipientId: string) => void;
  currentUserId: string;
  onToggleHistoryModal: () => void; // New prop
}

export const Header: React.FC<HeaderProps> = ({ 
  currentUserRole, 
  currentUserName, 
  notifications, 
  onClearNotifications, 
  currentUserId,
  onToggleHistoryModal 
}) => {
  const Icon = currentUserRole === UserRole.MANAGER ? ManagerIcon : null;

  return (
    <header className="bg-sky-700 text-white p-4 shadow-lg">
      <div className="container mx-auto flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">{APP_TITLE}</h1>
        <div className="flex items-center space-x-4 md:space-x-6">
          <div className="flex items-center space-x-2 bg-sky-600 px-3 py-1 rounded-full">
            {Icon && <Icon className="w-7 h-7 text-sky-200" />}
            <span className="text-lg font-medium">{currentUserName} ({currentUserRole === UserRole.MANAGER ? 'Manager' : 'Technician'})</span>
          </div>
          {currentUserRole === UserRole.MANAGER && (
            <button
              onClick={onToggleHistoryModal}
              className="p-2 rounded-full hover:bg-sky-600 focus:outline-none focus:ring-2 focus:ring-sky-400 focus:ring-opacity-75"
              title="View Service History"
              aria-label="View service history"
            >
              <ArchiveBoxIcon className="w-7 h-7 text-sky-100" />
            </button>
          )}
          <NotificationBell 
            notifications={notifications.filter(n => n.recipientId === currentUserId)} 
            onClearNotifications={() => onClearNotifications(currentUserId)} 
            recipientId={currentUserId}
          />
        </div>
      </div>
    </header>
  );
};
