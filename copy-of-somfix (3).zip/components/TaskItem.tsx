
import React from 'react';
import { Task, TaskStatus, UserRole } from '../types';
import { CheckIcon } from './icons/CheckIcon';
import { XMarkIcon } from './icons/XMarkIcon';
import { UserIcon } from './icons/UserIcon';
import { PhoneIcon, CogIcon, ClipboardDocumentListIcon, CheckBadgeIcon } from '../constants';
import { WrenchIcon } from './icons/WrenchIcon';


interface TaskItemProps {
  task: Task;
  currentUserRole: UserRole;
  currentUserId: string;
  onAcceptTask?: (taskId: string) => void;
  onRejectTask?: (taskId: string) => void;
  onCompleteTask?: (taskId: string) => void; // New prop
}

const getStatusColorClasses = (status: TaskStatus): string => {
  switch (status) {
    case TaskStatus.PENDING:
      return 'border-yellow-400 bg-yellow-50 text-yellow-800';
    case TaskStatus.ACCEPTED:
      return 'border-green-400 bg-green-50 text-green-800';
    case TaskStatus.REJECTED:
      return 'border-red-400 bg-red-50 text-red-800';
    case TaskStatus.COMPLETED:
      return 'border-blue-500 bg-blue-50 text-blue-800'; // Distinct style for completed
    default:
      return 'border-slate-400 bg-slate-50 text-slate-800';
  }
};

export const TaskItem: React.FC<TaskItemProps> = ({ task, currentUserRole, currentUserId, onAcceptTask, onRejectTask, onCompleteTask }) => {
  const technicianShare = task.totalAmountUSD * 0.40;
  const isAssignedToCurrentUser = task.assignedTechnicianId === currentUserId;

  const statusBadgeClasses = getStatusColorClasses(task.status);

  const canCompleteTask = (currentUserRole === UserRole.TECHNICIAN && isAssignedToCurrentUser && task.status === TaskStatus.ACCEPTED) ||
                          (currentUserRole === UserRole.MANAGER && (task.status === TaskStatus.ACCEPTED || task.status === TaskStatus.PENDING));

  return (
    <li className={`p-5 rounded-xl shadow-lg border-l-4 transition-all duration-300 hover:shadow-xl mb-4 ${statusBadgeClasses} ${task.status === TaskStatus.COMPLETED ? 'opacity-80' : ''}`}>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-3">
        <div className="flex-grow mb-2 sm:mb-0">
          <h3 className="text-xl font-semibold text-slate-800">{task.description}</h3>
          <p className="text-xs text-slate-500 mt-1">
            Task ID: {task.id} | Created: {new Date(task.createdAt).toLocaleDateString()} {new Date(task.createdAt).toLocaleTimeString()}
            {task.status === TaskStatus.COMPLETED && task.completedAt && (
                <> | Completed: {new Date(task.completedAt).toLocaleDateString()} {new Date(task.completedAt).toLocaleTimeString()}</>
            )}
          </p>
        </div>
        <span className={`px-3 py-1.5 text-sm font-semibold rounded-full whitespace-nowrap ${statusBadgeClasses}`}>
          {task.status}
        </span>
      </div>

      {/* Customer and Appliance Details Section */}
      <div className="mt-3 pt-3 border-t border-opacity-50 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3 text-sm">
          <div className="flex items-start text-slate-700">
            <UserIcon className="w-5 h-5 mr-2 text-sky-600 flex-shrink-0 mt-0.5" />
            <div>
              <span className="font-medium">Customer:</span> {task.customerName}
            </div>
          </div>
          <div className="flex items-start text-slate-700">
            <PhoneIcon className="w-5 h-5 mr-2 text-sky-600 flex-shrink-0 mt-0.5" />
            <div>
              <span className="font-medium">Phone:</span> {task.customerPhoneNumber}
            </div>
          </div>
          <div className="flex items-start text-slate-700">
            <CogIcon className="w-5 h-5 mr-2 text-indigo-600 flex-shrink-0 mt-0.5" />
            <div>
              <span className="font-medium">Appliance:</span> {task.applianceType}
            </div>
          </div>
           {currentUserRole === UserRole.MANAGER && task.assignedTechnicianName && (
            <div className="flex items-start text-slate-700">
                <WrenchIcon className="w-5 h-5 mr-2 text-teal-600 flex-shrink-0 mt-0.5" />
                <div>
                <span className="font-medium">Assigned:</span> {task.assignedTechnicianName}
                </div>
            </div>
            )}
        </div>
        <div className="flex items-start text-slate-700 text-sm">
          <ClipboardDocumentListIcon className="w-5 h-5 mr-2 text-purple-600 flex-shrink-0 mt-0.5" />
          <div>
            <span className="font-medium">Issue Details:</span> {task.failureDetails}
          </div>
        </div>
      </div>
      
      {/* Financials and Technician Info */}
      <div className="mt-4 pt-4 border-t border-opacity-50 flex flex-col space-y-3 sm:flex-row sm:space-y-0 sm:space-x-6 sm:items-center text-sm">
        <div className="flex items-center text-slate-600">
           <span className="text-lg mr-2">💰</span>
          {currentUserRole === UserRole.MANAGER ? (
            `Total: $${task.totalAmountUSD.toFixed(2)} (Technician gets $${technicianShare.toFixed(2)})`
          ) : (
            `Your Share: $${technicianShare.toFixed(2)}`
          )}
        </div>
      </div>

      <div className="mt-5 pt-4 border-t border-opacity-50 flex space-x-3 justify-end">
        {currentUserRole === UserRole.TECHNICIAN && isAssignedToCurrentUser && task.status === TaskStatus.PENDING && onAcceptTask && onRejectTask && (
          <>
            <button
              onClick={() => onRejectTask(task.id)}
              className="flex items-center px-5 py-2.5 rounded-lg text-sm font-medium text-red-700 bg-red-100 hover:bg-red-200 transition-colors duration-150 shadow hover:shadow-md"
              aria-label={`Reject task ${task.description}`}
            >
              <XMarkIcon className="w-5 h-5 mr-2" />
              Reject
            </button>
            <button
              onClick={() => onAcceptTask(task.id)}
              className="flex items-center px-5 py-2.5 rounded-lg text-sm font-medium text-white bg-green-600 hover:bg-green-700 transition-colors duration-150 shadow hover:shadow-md"
              aria-label={`Accept task ${task.description}`}
            >
              <CheckIcon className="w-5 h-5 mr-2" />
              Accept
            </button>
          </>
        )}
        {canCompleteTask && onCompleteTask && task.status !== TaskStatus.COMPLETED && (
           <button
            onClick={() => onCompleteTask(task.id)}
            className="flex items-center px-5 py-2.5 rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 transition-colors duration-150 shadow hover:shadow-md"
            aria-label={`Mark task as completed: ${task.description}`}
          >
            <CheckBadgeIcon className="w-5 h-5 mr-2" />
            Mark as Completed
          </button>
        )}
      </div>
    </li>
  );
};
