
import React from 'react';
import { CheckCircleIcon } from '../../constants';

export const CheckIcon: React.FC<{ className?: string }> = ({ className }) => (
  <CheckCircleIcon className={className} />
);
    