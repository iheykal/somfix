
import React, { useState, useEffect, useCallback } from 'react';
import { Technician, Task, TaskStatus, ApplianceType } from '../types';
import { PlusIcon } from './icons/PlusIcon';
import { 
  generateRandomSomaliName, 
  generateRandomSomaliPhoneNumber, 
  generateRandomFailureDetails,
  generateRandomTaskDescription,
  generateRandomAmount,
  getRandomElement
} from '../constants';

interface AddTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddTask: (task: Omit<Task, 'id' | 'status' | 'createdAt'>) => void;
  technicians: Technician[]; // Will now typically be an array with one technician
}

export const AddTaskModal: React.FC<AddTaskModalProps> = ({ isOpen, onClose, onAddTask, technicians }) => {
  const [description, setDescription] = useState('');
  const [assignedTechnicianId, setAssignedTechnicianId] = useState<string | null>(null);
  const [totalAmountUSD, setTotalAmountUSD] = useState<number>(0);
  
  const [customerName, setCustomerName] = useState('');
  const [customerPhoneNumber, setCustomerPhoneNumber] = useState('');
  const [applianceType, setApplianceType] = useState<ApplianceType | ''>('');
  const [failureDetails, setFailureDetails] = useState('');

  const [error, setError] = useState<string | null>(null);

  const populateWithRandomData = useCallback(() => {
    const randomAppliance = getRandomElement(Object.values(ApplianceType));
    setCustomerName(generateRandomSomaliName());
    setCustomerPhoneNumber(generateRandomSomaliPhoneNumber());
    setApplianceType(randomAppliance);
    setFailureDetails(generateRandomFailureDetails(randomAppliance));
    setDescription(generateRandomTaskDescription());
    setTotalAmountUSD(generateRandomAmount());
    
    // Auto-select the technician if there's only one
    if (technicians.length === 1) {
      setAssignedTechnicianId(technicians[0].id);
    } else {
      setAssignedTechnicianId(null); 
    }
  }, [technicians]);

  useEffect(() => {
    if (isOpen) {
      populateWithRandomData();
    }
  }, [isOpen, populateWithRandomData]);


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!description.trim()) {
      setError('Task description cannot be empty.');
      return;
    }
    if (!customerName.trim()) {
      setError('Customer name cannot be empty.');
      return;
    }
    if (!customerPhoneNumber.trim()) {
      setError('Customer phone number cannot be empty.');
      return;
    }
    if (!applianceType) {
      setError('Please select an appliance type.');
      return;
    }
    if (!failureDetails.trim()) {
      setError('Please provide failure details.');
      return;
    }
    if (!assignedTechnicianId) {
      // This check remains, ensuring a technician is always assigned.
      // With auto-selection for a single technician, this error should be less common.
      setError('Please assign a technician.');
      return;
    }
    if (totalAmountUSD <= 0) {
      setError('Total amount must be greater than zero.');
      return;
    }
    
    const selectedTechnician = technicians.find(t => t.id === assignedTechnicianId);
    if (!selectedTechnician) {
        setError('Invalid technician selected.');
        return;
    }

    onAddTask({
      description,
      assignedTechnicianId,
      assignedTechnicianName: selectedTechnician.name,
      totalAmountUSD,
      customerName,
      customerPhoneNumber,
      applianceType: applianceType as ApplianceType,
      failureDetails,
    });
    onClose();
  };

  if (!isOpen) return null;

  const singleTechnician = technicians.length === 1 ? technicians[0] : null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-gradient-to-br from-sky-50 to-indigo-100 p-6 sm:p-8 rounded-xl shadow-2xl w-full max-w-2xl transform transition-all duration-300 ease-in-out scale-100 my-8 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-800 flex items-center">
            <PlusIcon className="w-7 h-7 sm:w-8 sm:h-8 mr-3 text-sky-600" />
            Add New Task
          </h2>
          <button 
            onClick={onClose}
            className="text-slate-500 hover:text-slate-700 text-3xl font-light"
            aria-label="Close modal"
          >
            &times;
          </button>
        </div>
        
        {error && <p className="text-red-600 bg-red-100 p-3 rounded-md mb-4 text-sm animate-shake">{error}</p>}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-slate-700 mb-1">Task Description (Overall work)</label>
            <textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-3 border border-slate-300 rounded-lg shadow-sm focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition duration-150"
              rows={2}
              placeholder="e.g., Visit customer for appliance repair"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="customerName" className="block text-sm font-medium text-slate-700 mb-1">Customer Name</label>
              <input
                type="text"
                id="customerName"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full p-3 border border-slate-300 rounded-lg shadow-sm focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition duration-150"
                placeholder="e.g., John Doe"
              />
            </div>
            <div>
              <label htmlFor="customerPhoneNumber" className="block text-sm font-medium text-slate-700 mb-1">Customer Phone Number</label>
              <input
                type="tel"
                id="customerPhoneNumber"
                value={customerPhoneNumber}
                onChange={(e) => setCustomerPhoneNumber(e.target.value)}
                className="w-full p-3 border border-slate-300 rounded-lg shadow-sm focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition duration-150"
                placeholder="e.g., +252 61 XXX XXX"
              />
            </div>
          </div>

          <div>
            <label htmlFor="applianceType" className="block text-sm font-medium text-slate-700 mb-1">Appliance Type</label>
            <select
              id="applianceType"
              value={applianceType}
              onChange={(e) => {
                  const newApplianceType = e.target.value as ApplianceType | '';
                  setApplianceType(newApplianceType);
                  if (newApplianceType) {
                    setFailureDetails(generateRandomFailureDetails(newApplianceType as ApplianceType));
                  } else {
                    setFailureDetails('');
                  }
              }}
              className="w-full p-3 border border-slate-300 rounded-lg shadow-sm focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition duration-150 bg-white"
            >
              <option value="" disabled>Select appliance</option>
              {Object.values(ApplianceType).map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label htmlFor="failureDetails" className="block text-sm font-medium text-slate-700 mb-1">
              Failure Details / Problem Description
            </label>
            <textarea
              id="failureDetails"
              value={failureDetails}
              onChange={(e) => setFailureDetails(e.target.value)}
              className="w-full p-3 border border-slate-300 rounded-lg shadow-sm focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition duration-150"
              rows={3}
              placeholder="e.g., Fridge not cooling, Cooker heating element broken"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="technician" className="block text-sm font-medium text-slate-700 mb-1">Assign to Technician <span className="text-red-500">*</span></label>
              {singleTechnician ? (
                <div className="w-full p-3 border border-slate-300 rounded-lg shadow-sm bg-slate-100 text-slate-700">
                  {singleTechnician.name} (Auto-assigned)
                </div>
              ) : (
                <select
                  id="technician"
                  value={assignedTechnicianId || ''}
                  onChange={(e) => setAssignedTechnicianId(e.target.value)}
                  className="w-full p-3 border border-slate-300 rounded-lg shadow-sm focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition duration-150 bg-white"
                >
                  <option value="" disabled>Select a technician</option>
                  {/* This map will only render one option if technicians.length > 1, but we guard with singleTechnician above */}
                  {technicians.map(tech => (
                    <option key={tech.id} value={tech.id}>{tech.name}</option>
                  ))}
                </select>
              )}
            </div>
            <div>
              <label htmlFor="amount" className="block text-sm font-medium text-slate-700 mb-1">Total Amount (USD)</label>
              <input
                type="number"
                id="amount"
                value={totalAmountUSD}
                onChange={(e) => setTotalAmountUSD(parseFloat(e.target.value) || 0)}
                className="w-full p-3 border border-slate-300 rounded-lg shadow-sm focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition duration-150"
                placeholder="e.g., 150"
                min="0.01"
                step="0.01"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-3 sm:space-x-4 pt-2">
            <button 
              type="button" 
              onClick={onClose}
              className="px-5 py-2 sm:px-6 sm:py-2.5 rounded-lg text-slate-700 bg-slate-200 hover:bg-slate-300 transition duration-150 font-medium"
            >
              Cancel
            </button>
            <button 
              type="submit"
              className="px-5 py-2 sm:px-6 sm:py-2.5 rounded-lg text-white bg-sky-600 hover:bg-sky-700 focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 transition duration-150 font-medium shadow-md hover:shadow-lg"
            >
              Add Task
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};