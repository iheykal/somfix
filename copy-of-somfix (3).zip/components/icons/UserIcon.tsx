
import React from 'react';
import { UserCircleIcon as HeroUserCircleIcon } from '../../constants'; // Use the one from constants

export const UserIcon: React.FC<{ className?: string }> = ({ className }) => (
  <HeroUserCircleIcon className={className} />
);
    