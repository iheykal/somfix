
import React from 'react';
import { UserRole, Technician } from '../types';
import { INITIAL_TECHNICIANS, USER_ROLES_CONFIG } from '../constants';
import { BriefcaseIcon } from './icons/BriefcaseIcon';
// WrenchIcon is no longer used here

interface UserSwitchProps {
  currentUser: { role: UserRole; id: string; name: string };
  onSwitchUser: (role: UserRole, id: string, name: string) => void;
}

export const UserSwitch: React.FC<UserSwitchProps> = ({ currentUser, onSwitchUser }) => {
  const availableUsers = [
    { role: UserRole.MANAGER, id: USER_ROLES_CONFIG.MANAGER.id, name: USER_ROLES_CONFIG.MANAGER.name, Icon: BriefcaseIcon },
    ...INITIAL_TECHNICIANS.map(tech => ({ role: UserRole.TECHNICIAN, id: tech.id, name: tech.name, Icon: null })) // No icon for technicians
  ];

  return (
    <div className="my-6 p-4 bg-gradient-to-r from-slate-700 to-slate-800 rounded-xl shadow-2xl">
      <h2 className="text-xl font-semibold text-center text-slate-100 mb-4">Switch User View</h2>
      <div className="flex flex-wrap justify-center gap-3">
        {availableUsers.map(user => (
          <button
            key={user.id}
            onClick={() => onSwitchUser(user.role, user.id, user.name)}
            className={`flex items-center space-x-2 px-5 py-3 rounded-lg font-medium transition-all duration-150 ease-in-out
              ${currentUser.id === user.id 
                ? (user.role === UserRole.MANAGER ? 'bg-emerald-500 text-white shadow-lg ring-2 ring-emerald-300' : 'bg-sky-500 text-white shadow-lg ring-2 ring-sky-300')
                : 'bg-slate-200 text-slate-700 hover:bg-slate-300 hover:shadow-md'
              }`}
          >
            {user.Icon && <user.Icon className="w-5 h-5" />}
            <span>{user.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
};
