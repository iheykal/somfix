
import React from 'react';
import { TrashIcon } from '../../constants';

export const TrashCanIcon: React.FC<{ className?: string }> = ({ className }) => (
  <TrashIcon className={className} />
);
    