
import React from 'react';
import { XCircleIcon } from '../../constants';

export const XMarkIcon: React.FC<{ className?: string }> = ({ className }) => (
  <XCircleIcon className={className} />
);
    