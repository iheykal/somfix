
import React from 'react';
import { PlusCircleIcon } from '../../constants';

export const PlusIcon: React.FC<{ className?: string }> = ({ className }) => (
  <PlusCircleIcon className={className} />
);
    