
import React from 'react';
import { BellIcon as HeroBellIcon } from '../../constants'; // Use the one from constants

export const BellIcon: React.FC<{ className?: string }> = ({ className }) => (
  <HeroBellIcon className={className} />
);
    